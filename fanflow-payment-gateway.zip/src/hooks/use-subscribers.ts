import { useQuery, UseQueryOptions } from '@tanstack/react-query';
import type { Subscriber } from '@/components/dashboard/subscriber-table';

export interface SubscribersResponse {
  subscribers: Subscriber[];
  total: number;
  totalMRR: number;
}

async function fetchSubscribers(search: string = ''): Promise<SubscribersResponse> {
  const params = new URLSearchParams();
  if (search) {
    params.append('search', search);
  }
  
  const response = await fetch(`/api/v1/subscribers${params.toString() ? `?${params.toString()}` : ''}`);
  if (!response.ok) {
    throw new Error('Failed to fetch subscribers');
  }
  return response.json();
}

export function useSubscribers(
  search: string = '',
  options?: Omit<UseQueryOptions<SubscribersResponse>, 'queryKey' | 'queryFn'>
) {
  return useQuery<SubscribersResponse>({
    queryKey: ['subscribers', search],
    queryFn: () => fetchSubscribers(search),
    refetchInterval: 30000, // 30 seconds
    refetchIntervalInBackground: true,
    staleTime: 10000, // 10 seconds
    ...options,
  });
}